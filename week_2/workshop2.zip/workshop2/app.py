
from banking_pkg import account


def atm_menu(name):
    print("")
    print("          === Automated Teller Machine ===          ")
    print("User: " + name)
    print("------------------------------------------")
    print("| 1.    Balance     | 2.    Deposit      |")
    print("------------------------------------------")
    print("------------------------------------------")
    print("| 3.    Withdraw    | 4.    Logout       |")
    print("------------------------------------------")


print("          === Automated Teller Machine ===          ")

# Declare 3 boolean variables for (FLag) conditions
# Declare variable 'pin' --> which we will use as an argument for the function:
# of checking the correctness of pin code input
name_check_length = False
pin_check_length = False
pin_to_validate = False
pin = ""

while True:
    name = input("Enter name to register: ")
    if name == '':  # checking for empty input -> user
        print("Please enter your name: ")
    elif len(name) <= 10:  # check the length of name -> user
        name_check_length = True
        break

    else:
        print("<--- The maximum name length is 10 characters --->")
if name_check_length == True:  # these conditions are checked if the 'name_check_length' --> True
    while True:
        pin = (input("Enter PIN: "))
        if len(pin) == 4:  # check the length of PIN code
            pin_check_length = True
            break
        else:
            print("PIN must contain 4 numbers")
    balance = 0
    print("-------------------------------------------------------")
    # f strings with capitalize user name
    print(f"{name.title()} has been registered with a starting balance of $" + str(balance))
    print("-------------------------------------------------------")

    while (True):
        print("LOGIN")
        name_to_validate = input("Enter your name: ")
        if name_to_validate != name:
            print("*** Wrong name!Not registered user! ***")
        if name_to_validate == name:
            pin_to_validate = account.check_pin_code(int(pin))

        if (name_to_validate == name) and (pin_to_validate == True):
            print("Login successful!")
            break
        else:
            print("_____Invalid credentials!_____")

    while (True):
        atm_menu(name)
        option = input("Choose an option: ")
        if option == "1":
            account.show_balance(balance)
        elif option == "2":
            balance = account.deposit(balance)
            account.show_balance(balance)
        elif option == "3":
            balance, pos_amount = account.withdraw(balance)
            # if the desired amount of withdraw exceeds the balance, this message is displayed
            if pos_amount == False:
                print("Where are you going to get that kind of money?")
            account.show_balance(balance)
        elif option == "4":
            account.logout(name)
            break
