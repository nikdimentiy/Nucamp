def show_balance(balance):
    """The function show current balance of user"""
    print(f"Current Balance: ${balance}")


def deposit(balance):
    """The function implements depositing money into account"""
    amount = float(input("Enter amount to deposit: "))
    return balance + amount


def withdraw(balance):
    """The function implements withdraw money into account (with balance correction)"""
    amount = float(input("Enter amount to withdraw: "))
    differency = balance - amount
    if float(differency) < amount:
        return balance, False
    else:
        return differency, True


def logout(name):
    """Exit function"""
    print(f"Goodbye {name}!")


def check_pin_code(pin):
    """The function checks the correctness of PIN code entry """

    attempt = 3
    while attempt != 0:
        pin_code = input(
            f"Enter your PIN code. You have {attempt} attempts left: ")

        if len(pin_code) == 4:
            attempt -= 1

            if int(pin_code) == pin:  # correct PIN code
                return True

        else:
            # condition: checking for a valid number of input attempts (while loops --> attempt != 0)
            print("The pin-code must contains 4 numbers!")
            attempt -= 1

    if attempt == 0:
        print("Access denied!")
        return False
